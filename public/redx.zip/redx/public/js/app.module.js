angular.module('app',['ui.router', 'app.config', 'ngMessages', 'ngFileUpload']);
