/*global angular*/

angular.module('app')
.controller('registerCtrl',function($scope){


});
