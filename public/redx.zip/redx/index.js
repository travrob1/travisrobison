/*global require, __dirname, console, process */
var express = require('express');
var path = require('path');
var exphbs  = require('express-handlebars');
var passport = require('passport');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var flash    = require('connect-flash');
var session = require('cookie-session');
var _ = require('lodash');
var app = express();

app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/node_modules'));
app.use(cookieParser()); // read cookies (needed for auth)
app.use(bodyParser.urlencoded({extended: false})); // get information from html forms
app.use(bodyParser.json()); // get information from html forms

var templateDir = path.join(__dirname, 'templates/');
app.set('views', templateDir);
app.engine('handlebars', exphbs({
  defaultLayout: 'index',
  layoutsDir: templateDir,
  helpers: {
    json: function(context) {
      return JSON.stringify(context);
    }
  }
}));
app.set('view engine', 'handlebars');

// configuration ===============================================================
// required for passport
app.use(session({ secret: 'ilovecodecodingcodecoddeingcode' })); // session secret
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions
app.use(flash()); // use connect-flash for flash messages stored in session
// mongoose.connect('mongodb://vo@localhost/vo'); // connect to our database
mongoose.connect('mongodb://trav:trav@ds245277.mlab.com:45277/trav'); // connect to our database
require('./server/passport.config')(passport); // pass passport for configuration

// routes ======================================================================
require('./server/app-routes.js')(app, _);
require('./server/auth-routes.js')(app, passport, _);


// start the server ======================================================================
console.log('[%s] Listening on http://localhost:%d', app.settings.env, process.env.PORT || 5002);
app.listen(process.env.PORT || 5002);
