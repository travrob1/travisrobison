
var fs = require('fs');
var multer = require('multer');

var storage = multer.diskStorage({
  // destination
  destination: function (req, file, cb) {
      if (! fs.existsSync(`public/uploads/${req.user._id}`)) {
          fs.mkdirSync(`public/uploads/${req.user._id}`);
      }
      cb(null, `public/uploads/${req.user._id}`);
  } ,
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});
var upload = multer({ storage: storage });


module.exports = function(app, _) {

    app.get('/', function(req, res) {
        res.render('index', {
            config: JSON.stringify({
                user: req.user || false,
                message: req.flash('authMessage')
            })
        });
    });

    app.post('/image-upload', upload.single('myFile'), function (req, res, next) {
        res.end();
  });

    app.get('/get-images',function (req,res) {

        fs.readdir(`public/uploads/${req.user._id}`, function(err, items) {
            res.json(items);
        });
    });

};
