angular.module('app').config(function ($stateProvider, $urlRouterProvider) {
    var requireAuthUser = {
        authUser: function($rootScope, $q){
            if (!$rootScope.authenticatedUser){
                $q.reject('no auth user');
            }
        }
    };

    $stateProvider
        .state('home', {
            url: '/',
            templateUrl: 'js/home/home.html',
            controller: 'registerCtrl'
        }).state('home2', { // some weird work around with ui -router so a standar / does not redirect to 404
            url: '',
            templateUrl: 'js/home/home.html',
            controller: 'registerCtrl'
        }).state('account', {
            url: '/account',
            templateUrl: 'js/account/account.html',
            controller: 'accountCtrl',
            authenticate: true
        });

    $urlRouterProvider.otherwise('404');
});

angular.module('app').run(function($rootScope, $state, $timeout, AuthService) {

    $rootScope.$on('$stateChangeStart', function(event, next) {
        $('html body').scrollTop( 0 );
        // redirect to login page if not logged in
        if (next.authenticate && !$rootScope.authenticatedUser) {
            // the user might be logged in, but authenticatedUser has not been set to scope on a page refresh
            AuthService.getCurrent()
                .catch(function(){
                    event.preventDefault(); //prevent current page from loading
                    $state.go('home');
                });
        }
    });
});

angular.module('app').controller('globalCtrl', function($scope, $location, $http, AuthService, state, config){
    AuthService.getCurrent();
});
