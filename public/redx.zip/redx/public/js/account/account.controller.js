'use strict';
/*global angular, $, _*/
angular.module('app').controller('accountCtrl',function($scope, $state, $http, $parse, AuthService, Upload, $timeout){
    AuthService.getCurrent();
    $scope.user = {};
    $scope.userPasswords = {};

    $scope.photo = $scope.$root.authenticatedUser.photo || '/images/avatar.png';

    $scope.userUpdate = function(){
        AuthService.userUpdate($scope.$root.authenticatedUser)
    };

    $scope.upload = function (file) {
        Upload.upload({
            url: '/image-upload',
            arrayKey: '',
            data: {
                myFile: file
            },
        }).then(function (response) {
            $timeout(function () {
                $scope.getImages();
            });
        }).catch(function (err) {
        });
    };

    $scope.getImages = function() {
        $http.get('/get-images')
            .then(function(res) {
                $scope.galleryImages = res.data.map(function (image) {
                    return 'uploads/'+ $scope.authenticatedUser._id + '/' + image;
                });

            });
    };
    $scope.getImages();
    $scope.showLinkForm = function(){
        $scope.connectLocal = true;
    };
    $scope.updatepassword = function(){
        $http.post('/updatepassword', {
            existing: $scope.newPass.existing,
            new: $scope.newPass.new,
            newConf: $scope.newPass.newConf
        }).then(function(res){
            if(res.data.notification){
                $scope.$root.notification = res.data.notification;
            }
        });
    };

});
